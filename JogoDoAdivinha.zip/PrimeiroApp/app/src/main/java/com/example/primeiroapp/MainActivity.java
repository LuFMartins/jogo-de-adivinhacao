package com.example.primeiroapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText entrada;
    private TextView numero;
    private ImageView setaCima;
    private ImageView setaBaixo;
    private TextView dica;
    private TextView tentativas;
    private int tent = 0;
    private ImageView interr;
    private int numeroale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        entrada = findViewById(R.id.entrada); // Verifique o ID
        numero = findViewById(R.id.numero);   // Verifique o ID
        setaCima = findViewById(R.id.setaCima);   // Verifique o ID
        setaBaixo = findViewById(R.id.setaBaixo);   // Verifique o ID
        dica = findViewById(R.id.dica);  // Verifique o ID
        tentativas = findViewById(R.id.tentativas); // Verifique o ID
        interr = findViewById(R.id.interr);// Verifique o ID

        Random aleatorio = new Random();
        numeroale = aleatorio.nextInt(100);
        numero.setText(String.valueOf(numeroale));

    }

    public void Enviar(View view) {

        tent += 1;


        int entradaTexto = Integer.parseInt(entrada.getText().toString());
        int numeroTexto = Integer.parseInt(numero.getText().toString());

        if(entradaTexto == numeroTexto){
            interr.setVisibility(View.INVISIBLE);
            numero.setVisibility(View.VISIBLE);
            numero.setTextColor(getResources().getColor(R.color.teal_200));
            setaCima.setBackgroundColor(getResources().getColor(R.color.padrao));
            setaBaixo.setBackgroundColor(getResources().getColor(R.color.padrao));
        } else {
            tentativas.setText("Tentativas " + tent);
            if(entradaTexto < numeroTexto){
                setaCima.setBackgroundColor(getResources().getColor(R.color.teal_700));
                setaBaixo.setBackgroundColor(getResources().getColor(R.color.padrao));
            } else {
                setaCima.setBackgroundColor(getResources().getColor(R.color.padrao));
                setaBaixo.setBackgroundColor(getResources().getColor(R.color.teal_700));
            }
        }
    }

    public void gerarDica(View view) {
        if(numeroale%2==0){
            dica.setText("Par!");
        } else {
            dica.setText("Impar!");
        }
    }
}